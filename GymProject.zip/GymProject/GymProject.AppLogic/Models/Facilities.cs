﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GymProject.AppLogic.Models
{
    public class Facilities
    {
        public Guid Id { get; set; }
        public PriceAbonament priceAbonamentId { get; set; }
        public string AbonamentFacilities { get; set; }


    }
}
